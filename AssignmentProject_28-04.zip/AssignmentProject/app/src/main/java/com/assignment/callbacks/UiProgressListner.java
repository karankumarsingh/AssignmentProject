package com.assignment.callbacks;

public interface UiProgressListner {
    void showProgress();
    void hideProgress();
}
