package com.assignment;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.assignment.ui.fragment.QuestionFragment;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MainActivity extends AppCompatActivity {

    @BindView(R.id.txt_title)
    public TextView txt_title;

    @BindView(R.id.img_back)
    ImageView img_back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        getSupportFragmentManager().beginTransaction().add(R.id.container, new QuestionFragment(), "QuestionFragment").commit();
    }

    public void setHeader(String title, boolean showBackButton){
        txt_title.setText(title);
        if(showBackButton)
            img_back.setVisibility(View.VISIBLE);
        else
            img_back.setVisibility(View.GONE);

    }
    @OnClick({R.id.img_back})
    public void onClickEvent(View v) {
        switch (v.getId()) {
            case R.id.img_back:
                finish();
                break;
        }
    };

        @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
