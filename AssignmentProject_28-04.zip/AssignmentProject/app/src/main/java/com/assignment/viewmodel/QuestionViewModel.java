package com.assignment.viewmodel;

import android.content.Context;

import androidx.lifecycle.ViewModel;


import com.assignment.model.Question;
import com.assignment.model.Request;
import com.assignment.utilities.Utilities;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.List;


public class QuestionViewModel extends ViewModel {

    Context mContext;
    QuestionViewModelListener modelListener;
    public QuestionViewModel(Context con, QuestionViewModelListener modelListener) {
        this.mContext = con;
        this.modelListener=modelListener;
    }


    public void callAPIService() {

        Type collectionType = new TypeToken<Request>() {}.getType();
        String myJSON = Utilities.parseJsonData(mContext, "questions.json");

        Request enums = new Gson().fromJson(myJSON, collectionType);
        List<Question> questionList=enums.getQuestionList();
        modelListener.langsSuccessResponse(questionList);

    }

    public interface QuestionViewModelListener {

        void langsSuccessResponse(List<Question> response);

        void langsFailureResponse(String msg);

    }
}