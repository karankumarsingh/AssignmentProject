package com.assignment.ui.fragment;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.assignment.MainActivity;
import com.assignment.R;
import com.assignment.callbacks.UiProgressListner;
import com.assignment.model.Answer;
import com.assignment.model.Question;
import com.assignment.viewmodel.QuestionViewModel;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

import static com.assignment.utilities.Utilities.disableView;
import static com.assignment.utilities.Utilities.enableView;

/**
 * Created by Charles I on 7/11/2018.
 */

public class QuestionFragment extends Fragment implements QuestionViewModel.QuestionViewModelListener, UiProgressListner {

    @BindString(R.string.next)
    String mNext;
    @BindString(R.string.back)
    String mBack;
    @BindString(R.string.finish)
    String mFinish;

    @BindView(R.id.txt_question)
    TextView mTextViewQuestion;

    @BindView(R.id.rd_group_options)
    RadioGroup rdGrpQuestion;
    @BindView(R.id.rd_btn_option1)
    RadioButton rdBtnOption1;
    @BindView(R.id.rd_btn_option2)
    RadioButton rdBtnOption2;
    @BindView(R.id.rd_btn_option3)
    RadioButton rdBtnOption3;
    @BindView(R.id.rd_btn_option4)
    RadioButton rdBtnOption4;

    @BindView(R.id.btn_back)
    Button btnBack;

    @BindView(R.id.btn_next)
    Button btnNext;

    @BindView(R.id.progressbar)
    ProgressBar mProgressBar;


    QuestionViewModel questionViewModel;
    List<Question> questionList;
    List<Answer> answerLists;

    int mCount=0;
    private String answerOpt="";

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        questionList=new ArrayList<>();
        answerLists=new ArrayList<>();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_question, container, false);
        ButterKnife.bind(this, view);
        initView();
        return view;
    }

    private void initView() {
        ((MainActivity) getContext()).setHeader("Start your test", false);
        questionViewModel= new QuestionViewModel(getContext(), this);
        questionViewModel.callAPIService();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @OnClick({R.id.btn_next, R.id.btn_back, R.id.rd_btn_option1, R.id.rd_btn_option2, R.id.rd_btn_option3, R.id.rd_btn_option4, R.id.rd_group_options})
    public void onClickEvent(View v) {
        switch (v.getId()) {
            case R.id.rd_group_options:
                break;
            case R.id.rd_btn_option1:
                answerOpt=rdBtnOption1.getText().toString();
                break;
            case R.id.rd_btn_option2:
                answerOpt=rdBtnOption2.getText().toString();
                break;
            case R.id.rd_btn_option3:
                answerOpt=rdBtnOption3.getText().toString();
                break;
            case R.id.rd_btn_option4:
                answerOpt=rdBtnOption4.getText().toString();
                break;
            case R.id.btn_back:
                if(questionList!=null&&questionList.size()>0&&mCount>0){
                    int index=mCount-1;
                    /////populating previous question data//////////
                    populateData(index);
                    ///////////setting radio button previous state''
                    setRadioButton(index);
                    mCount--;
                }else {
                    btnBack.setBackgroundColor(Color.GRAY);
                    btnBack.setEnabled(false);
                }
                break;
            case R.id.btn_next:
                mCount++;
                if(questionList!=null&&questionList.size()>0&& mCount<3&&!answerOpt.isEmpty()){
                    ///Storing user answer//////////
                    storeData(mCount);

                    ////////////////Populating next question
                    populateData(mCount);
                    btnNext.setText(mNext);
                    ///enabling back button to go back
                    btnBack.setBackgroundColor(getResources().getColor(R.color.red));
                    btnBack.setEnabled(true);
                    this.answerOpt ="";
                    //////Condition to show last question//////
                    if(mCount==3){
                        btnNext.setText("Finish");
                    }
                    /////////////////Clear last time checked radiobutton state
                    rdGrpQuestion.clearCheck();

                } else if(mCount==3){
                    ///Storing user answer//////////
                    storeData(mCount);
                    AnswerListFragment answerListFragment=new AnswerListFragment();
                    Bundle bundle=new Bundle();
                    bundle.putSerializable("answer", (Serializable) answerLists);
                    answerListFragment.setArguments(bundle);
                    getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.container, answerListFragment, "Answer").commit();
                }else if (answerOpt.isEmpty()){
                    Toast.makeText(getActivity(), "Please select an option to proceed", Toast.LENGTH_LONG).show();
                }
                break;
            default:
        }
    }

    @Override
    public void langsSuccessResponse(List<Question> response) {

        if(response!=null&&response.size()>0){
            questionList=response;
            ///////////Populating data to the view////////////////
            populateData(0);
            btnBack.setText(mBack);
            btnNext.setText(mNext);
            btnBack.setBackgroundColor(Color.GRAY);
            /////Disabling back button for the first time
            btnBack.setEnabled(false);
        }

    }

    @Override
    public void langsFailureResponse(String msg) {


    }

    @Override
    public void showProgress() {
        if (null != mProgressBar && null != getActivity()) {
            mProgressBar.setVisibility(View.VISIBLE);
            disableView(getActivity());
        }
    }
    @Override
    public void hideProgress() {
        if (null != mProgressBar && null != getActivity()) {
            mProgressBar.setVisibility(View.GONE);
            enableView(getActivity());
        }
    }

    public void populateData(int pos){
        mTextViewQuestion.setText(questionList.get(pos).getQuestion());
        rdBtnOption1.setText(questionList.get(pos).getOptA());
        rdBtnOption2.setText(questionList.get(pos).getOptB());
        rdBtnOption3.setText(questionList.get(pos).getOptC());
        rdBtnOption4.setText(questionList.get(pos).getOptD());

    }

    public void storeData(int pos){
        Answer answer=new Answer();
        answer.setQuestion(mTextViewQuestion.getText().toString());
        answer.setQuestionAnswer(questionList.get(pos-1).getQuestionAnswer().toString());
        answer.setOptChosen(answerOpt);
        answerLists.add(answer);

    }

    public void setRadioButton(int index){
        if(answerLists.get(index).getOptChosen()==questionList.get(index).getOptA()){
            rdBtnOption1.setChecked(true);
        }else if(answerLists.get(index).getOptChosen()==questionList.get(index).getOptB()){
            rdBtnOption2.setChecked(true);
        }else if(answerLists.get(index).getOptChosen()==questionList.get(index).getOptC()){
            rdBtnOption3.setChecked(true);
        }else if(answerLists.get(index).getOptChosen()==questionList.get(index).getOptD()){
            rdBtnOption4.setChecked(true);
        }
        answerOpt=answerLists.get(index).getOptChosen();

        /////////////Removing previously added data///////
        answerLists.remove(index);

    }


}
