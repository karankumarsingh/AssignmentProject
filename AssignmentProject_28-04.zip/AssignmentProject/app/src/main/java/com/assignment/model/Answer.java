package com.assignment.model;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class Answer implements Serializable {

    private String question;
    private String questionAnswer;
    String optChosen;

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getQuestionAnswer() {
        return questionAnswer;
    }

    public void setQuestionAnswer(String questionAnswer) {
        this.questionAnswer = questionAnswer;
    }

    public String getOptChosen(){
        return optChosen;
    }

    public void setOptChosen(String optChosen) {
        this.optChosen = optChosen;
    }
}
