package com.assignment.ui.fragment;

import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.assignment.MainActivity;
import com.assignment.R;
import com.assignment.adapter.AnswerListAdapter;
import com.assignment.callbacks.UiProgressListner;
import com.assignment.model.Answer;
import com.assignment.model.Question;
import com.assignment.viewmodel.QuestionViewModel;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

import static com.assignment.utilities.Utilities.disableView;
import static com.assignment.utilities.Utilities.enableView;

/**
 * Created by Charles I on 7/11/2018.
 */

public class AnswerListFragment extends Fragment {


    @BindView(R.id.btn_complete)
    Button btnComplete;

    List<Answer> answerList;

    @BindView(R.id.recyclerView)
    RecyclerView mRecyclerView;

    AnswerListAdapter mBaseAddapter;
    LinearLayoutManager mLayoutManager;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle=getArguments();
        answerList= (List<Answer>) bundle.getSerializable("answer");
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_answerlist, container, false);
        ButterKnife.bind(this, view);
        initView();
        return view;
    }

    private void initView() {
        ((MainActivity) getContext()).setHeader("Your test report", true);
        mLayoutManager = new LinearLayoutManager(getContext());
        mLayoutManager.setOrientation(RecyclerView.VERTICAL);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mBaseAddapter = new AnswerListAdapter(getActivity(), answerList);
        mRecyclerView.setAdapter(mBaseAddapter);
    }


    @OnClick({R.id.btn_complete})
    public void onClickEvent(View v) {
        switch (v.getId()) {
            case R.id.btn_complete:
                getActivity().finish();
                break;
            default:
        }
    }




}
