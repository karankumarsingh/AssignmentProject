package com.assignment.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.assignment.R;
import com.assignment.model.Answer;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class AnswerListAdapter extends RecyclerView.Adapter<AnswerListAdapter.ViewHolder> {
    private Context mContext;
    private List<Answer> answerList;


    public AnswerListAdapter(FragmentActivity activity, List<Answer> answerList) {
        this.mContext = activity;
        this.answerList = answerList;

    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater inflater = ((Activity) mContext).getLayoutInflater();
        View view = inflater.inflate(R.layout.item_empty_view, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {

        viewHolder.txt_question.setText(answerList.get(i).getQuestion());
        viewHolder.txt_correct_Answer.setText("Correcr Answer: "+answerList.get(i).getQuestionAnswer());
        viewHolder.txt_your_answer.setText("Your Answe: "+answerList.get(i).getOptChosen());

    }

    @Override
    public int getItemCount() {
        if (answerList== null) {
            return 0;
        }
        return answerList.size();

    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.txt_question)
        TextView txt_question;
        @BindView(R.id.txt_correct_Answer)
        TextView txt_correct_Answer;
        @BindView(R.id.txt_your_answer)
        TextView txt_your_answer;


        ViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);

        }
    }
}
