package com.assignment.utilities;

import android.app.Activity;
import android.content.Context;
import android.content.res.AssetManager;
import android.os.Build;
import android.view.WindowManager;

import androidx.annotation.RequiresApi;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Utilities {
    public static String parseJsonData(Context con, String fileName) {

        if (con == null) {
            return "";
        } else {
            return convertFileTOString(con, fileName);
        }
    }

    /**
     * Converting file to String
     *
     * @param con
     * @param fileName
     * @return
     */
    public static String convertFileTOString(Context con, String fileName) {
        // handling NullPointerException
        StringBuilder content = new StringBuilder();
        AssetManager assetManager = con.getResources().getAssets();
        if (fileName != null && !fileName.isEmpty()) {
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(assetManager.open(fileName)))) {

                String line;
                while ((line = reader.readLine()) != null) {
                    content = content.append(line);
                }
            } catch (IllegalStateException e) {
                e.printStackTrace();
            } catch (ClassCastException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return content.toString();
    }
    /**
     * disable the view from touchable
     *
     * @param activity
     */
    public static void disableView(Activity activity) {
        if (activity != null) {
            activity.getWindow().setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
        }
    }

    /**
     * Enable the view for touchable
     *
     * @param activity
     */
    public static void enableView(Activity activity) {
        if (activity != null) {
            activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
        }
    }


}
